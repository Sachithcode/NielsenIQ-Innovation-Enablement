import torch

# Load YOLOv5 model (downloads if not available)
model = torch.hub.load("ultralytics/yolov5", "yolov5s", pretrained=True)
model.eval()
