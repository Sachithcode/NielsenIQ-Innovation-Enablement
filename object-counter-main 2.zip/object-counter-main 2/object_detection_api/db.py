import os
import psycopg2
from flask import Flask, request, jsonify
from werkzeug.utils import secure_filename

app = Flask(__name__)

# Database connection
conn = psycopg2.connect(
    dbname="object_counter",
    user="sachiths",
    password="your_password",  # Replace with your actual password
    host="localhost",
    port="5432"
)
cur = conn.cursor()

UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

# Object detection function (Placeholder)
def detect_objects(image_path, threshold=0.5):
    """
    Simulated object detection. In actual implementation, call your model.
    """
    detected_objects = [
        {"class": "person", "confidence": 0.8},
        {"class": "car", "confidence": 0.7},
        {"class": "dog", "confidence": 0.6}
    ]
    return [obj for obj in detected_objects if obj["confidence"] >= threshold]

# API Route: Upload Image & Detect Objects
@app.route("/detect", methods=["POST"])
def detect():
    if "image" not in request.files:
        return jsonify({"error": "No image uploaded"}), 400
    
    image = request.files["image"]
    threshold = float(request.form.get("threshold", 0.5))

    filename = secure_filename(image.filename)
    image_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
    image.save(image_path)

    detected_objects = detect_objects(image_path, threshold)

    for obj in detected_objects:
        cur.execute("INSERT INTO detected_objects (image_name, object_class, confidence) VALUES (%s, %s, %s)",
                    (filename, obj["class"], obj["confidence"]))
        conn.commit()

    return jsonify({"image": filename, "detected_objects": detected_objects})

if __name__ == "__main__":
    app.run(debug=True)

