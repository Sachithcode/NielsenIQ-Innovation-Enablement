from fastapi import FastAPI, File, UploadFile, Form
from io import BytesIO
import torch
from PIL import Image
import psycopg2
import datetime

# Load YOLOv5 model
model = torch.hub.load("ultralytics/yolov5", "yolov5s", force_reload=True)

app = FastAPI()

# Global dictionary to store cumulative counts
total_counts = {}

# PostgreSQL Database Configuration
DB_NAME = "object_counter"
DB_USER = "object_user"
DB_PASSWORD = "your_secure_password"
DB_HOST = "localhost"
DB_PORT = "5432"

def connect_db():
    """
    Connects to the PostgreSQL database.
    """
    try:
        conn = psycopg2.connect(
            dbname=DB_NAME,
            user=DB_USER,
            password=DB_PASSWORD,
            host=DB_HOST,
            port=DB_PORT
        )
        print("✅ Successfully connected to PostgreSQL!")
        return conn
    except Exception as e:
        print(f"❌ Error connecting to database: {e}")
        return None

def create_table():
    """
    Creates a table to store detected objects if it does not exist.
    """
    conn = connect_db()
    if conn:
        try:
            cur = conn.cursor()
            cur.execute("""
                CREATE TABLE IF NOT EXISTS detected_objects (
                    id SERIAL PRIMARY KEY,
                    object_name TEXT NOT NULL,
                    confidence FLOAT NOT NULL,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );
            """)
            conn.commit()
            print("✅ Table 'detected_objects' created successfully!")
        except Exception as e:
            print(f"❌ Error creating table: {e}")
        finally:
            cur.close()
            conn.close()

# Create table on startup
create_table()

@app.post("/detect/")
async def detect_objects(file: UploadFile = File(...), threshold: float = Form(0.5)):
    """
    Detects objects in an uploaded image using YOLOv5 and saves results to the database.
    
    Parameters:
        - file (UploadFile): The image file to process.
        - threshold (float): Confidence threshold for object detection. Default is 0.5.
    
    Returns:
        - JSON response with detected objects in the image and cumulative counts.
    """
    global total_counts

    # Read image
    image = Image.open(BytesIO(await file.read()))

    # Perform detection
    results = model(image)
    detections = results.pandas().xyxy[0]

    # Process detections with confidence filtering
    detected_objects = {}
    conn = connect_db()
    if conn:
        try:
            cur = conn.cursor()
            for _, row in detections.iterrows():
                if row["confidence"] >= threshold:  # Apply threshold filtering
                    label = row["name"]
                    confidence = row["confidence"]

                    detected_objects[label] = detected_objects.get(label, 0) + 1

                    # Insert detected object into PostgreSQL database
                    cur.execute(
                        "INSERT INTO detected_objects (object_name, confidence) VALUES (%s, %s);",
                        (label, confidence)
                    )
            
            conn.commit()
        except Exception as e:
            print(f"❌ Error inserting data: {e}")
        finally:
            cur.close()
            conn.close()

    # Update global total counts
    for obj, count in detected_objects.items():
        total_counts[obj] = total_counts.get(obj, 0) + count

    total_detected = sum(detected_objects.values())  # Objects in this image
    total_uploaded_detected = sum(total_counts.values())  # Across all images

    return {
        "detected_objects": detected_objects,
        "total_objects_in_image": total_detected,
        "total_objects_across_uploads": total_uploaded_detected,
    }

@app.get("/fetch/")
async def fetch_objects():
    """
    Fetches all detected objects from the database.
    
    Returns:
        - JSON response with stored object data.
    """
    conn = connect_db()
    if conn:
        try:
            cur = conn.cursor()
            cur.execute("SELECT * FROM detected_objects;")
            rows = cur.fetchall()
            objects = [
                {"id": row[0], "object_name": row[1], "confidence": row[2], "timestamp": row[3]}
                for row in rows
            ]
            return objects
        except Exception as e:
            return {"error": str(e)}
        finally:
            cur.close()
            conn.close()

@app.post("/reset/")
async def reset_counts():
    """
    Resets the total object counts across all uploaded images.
    
    Returns:
        - Confirmation message.
    """
    global total_counts
    total_counts.clear()
    return {"message": "Object count reset successfully."}
