import cv2
import numpy as np
from model import model

def detect_objects(image_path: str, threshold: float):
    # Read image
    image = cv2.imread(image_path)

    # Run inference
    results = model(image)

    # Get detections in a Pandas DataFrame format
    detections = results.pandas().xyxy[0]

    # Filter results based on confidence threshold
    filtered_detections = detections[detections["confidence"] > threshold]

    # Group detections by class and count
    detected_objects = filtered_detections["name"].value_counts().to_dict()

    return detected_objects
