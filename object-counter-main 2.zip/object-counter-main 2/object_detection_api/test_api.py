import os
import pytest
import requests
from app import app  # Import the Flask app

BASE_URL = "http://127.0.0.1:5000"

@pytest.fixture
def client():
    app.config["TESTING"] = True
    with app.test_client() as client:
        yield client

def test_home(client):
    """Test the home endpoint"""
    response = client.get("/")
    assert response.status_code == 200
    assert response.json == {"message": "Object Detection API is Running!"}

def test_file_upload(client):
    """Test file upload"""
    file_path = "test_image.jpg"  # Use an actual test image
    with open(file_path, "rb") as img:
        response = client.post(f"{BASE_URL}/upload", files={"file": img})
    
    assert response.status_code == 200
    assert "File uploaded successfully!" in response.json["message"]
