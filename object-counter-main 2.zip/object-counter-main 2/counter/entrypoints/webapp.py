from io import BytesIO
from flask import Flask, request, jsonify
from counter import config

def create_app():
    app = Flask(__name__)
    count_action = config.get_count_action()

    @app.route('/', methods=['GET'])
    def home():
        return jsonify({"message": "Object Counter API is running!"})

    @app.route('/object-count', methods=['POST'])
    def object_detection():
        if 'file' not in request.files:
            return jsonify({"error": "No file provided"}), 400
        
        uploaded_file = request.files['file']
        threshold = float(request.form.get('threshold', 0.5))

        try:
            image = BytesIO()
            uploaded_file.save(image)

            # Execute object detection
            count_response = count_action.execute(image, threshold)
            return jsonify(count_response)

        except Exception as e:
            return jsonify({"error": str(e)}), 500
    
    return app

if __name__ == '__main__':
    app = create_app()
    app.run(host='0.0.0.0', port=5000, debug=True)
