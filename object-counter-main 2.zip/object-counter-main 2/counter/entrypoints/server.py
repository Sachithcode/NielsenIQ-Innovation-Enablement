from fastapi import FastAPI
import tensorflow as tf
import numpy as np

app = FastAPI()
model = tf.keras.models.load_model("models/rfcn")

@app.post("/predict/")
async def predict(data: dict):
    input_data = np.array(data["input"])
    prediction = model.predict(input_data)
    return {"prediction": prediction.tolist()}
