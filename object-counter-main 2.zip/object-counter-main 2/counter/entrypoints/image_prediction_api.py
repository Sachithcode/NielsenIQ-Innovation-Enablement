from fastapi import FastAPI, UploadFile, File, Form
import requests
import numpy as np
import cv2
import json

app = FastAPI()

TENSORFLOW_SERVING_URL = "http://localhost:8501/v1/models/rfcn:predict"

@app.post("/predict")
async def predict(image: UploadFile = File(...), threshold: float = Form(...)):
    # Read image
    contents = await image.read()
    nparr = np.frombuffer(contents, np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    
    # Preprocess image (normalize, resize, etc. if needed)
    img = cv2.resize(img, (300, 300)) / 255.0  # Example resizing
    img = np.expand_dims(img, axis=0)  # Add batch dimension
    
    # Prepare payload
    payload = {"instances": img.tolist()}
    
    # Send request to TensorFlow Serving
    response = requests.post(TENSORFLOW_SERVING_URL, json=payload)
    
    if response.status_code != 200:
        return {"error": "Failed to get predictions", "details": response.text}
    
    predictions = response.json()["predictions"][0]
    
    # Filter predictions by threshold
    filtered_predictions = [pred for pred in predictions if pred[1] >= threshold]  # Assuming second index is confidence
    
    return {"predictions": filtered_predictions}
